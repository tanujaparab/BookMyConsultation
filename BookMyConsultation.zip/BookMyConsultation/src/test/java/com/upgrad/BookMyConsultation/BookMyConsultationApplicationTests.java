package com.upgrad.BookMyConsultation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyConsultationApplicationTests {

	@Test
	void contextLoads() {
	}

}
