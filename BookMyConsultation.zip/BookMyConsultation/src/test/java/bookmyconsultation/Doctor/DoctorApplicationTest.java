package bookmyconsultation.Doctor;

import static org.junit.jupiter.api.Assertions.*;

class DoctorApplicationTest {

}