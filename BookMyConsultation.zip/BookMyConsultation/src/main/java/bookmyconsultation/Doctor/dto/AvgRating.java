package bookmyconsultation.Doctor.dto;

import lombok.Data;

@Data
public class AvgRating {
    private String doctorId;
    private Double avgRating;
}
