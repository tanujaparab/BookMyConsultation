package bookmyconsultation.Doctor.dto;

import lombok.Data;

@Data
public class ApproveDoctorDto {
    private String approvedBy;
    private String approverComments;
}
