package bookmyconsultation.Doctor.dto;



import bookmyconsultation.Doctor.customvalidator.CustomEmailValidator;
import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;


@Data
public class DoctorDto {

    private String id;

    @NotBlank(message = "First Name cannot be blank")
    @Size(max =20, message = "First Name should have 20 characters")
    private String firstName;

    @NotBlank(message = "Last Name cannot be blank")
    @Size(max =20, message = "Last Name should have 20 characters")
    private String lastName;

    private String speciality="GENERAL_PHYSICIAN";

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE, pattern = "dd-MM-yyyy")
    @JsonFormat(pattern = "dd-MM-yyyy")
    @Pattern(regexp="(^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$)", message = "Please enter a valid date")
    private String dob;

    @NotBlank
    @Pattern(regexp="(^[0-9]{10})", message = "Please enter a valid mobile no")
    private String mobile;

    @NotBlank
    @CustomEmailValidator
    private String emailId;

    @NotBlank(message = "Pan cannot be blank")
    @Pattern(regexp="(^[a-zA-Z0-9]{10})", message = "Please enter a valid PAN number")
    private String pan;

    private String status;

    private String registrationDate;

    private Double avgRating;
}
