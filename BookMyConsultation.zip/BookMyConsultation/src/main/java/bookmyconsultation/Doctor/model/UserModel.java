package bookmyconsultation.Doctor.model;

import lombok.Data;


@Data
public class UserModel {

    private String username;

    private String password;

    private String role;

}
