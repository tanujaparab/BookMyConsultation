package bookmyconsultation.Doctor.controller;

import appointmentservice.mapper.ModelMapper;
import bookmyconsultation.Doctor.dto.ActiveDoctorDto;
import bookmyconsultation.Doctor.dto.ApproveDoctorDto;
import bookmyconsultation.Doctor.dto.DoctorDto;
import bookmyconsultation.Doctor.entity.DoctorEntity;
import bookmyconsultation.Doctor.service.DoctorService;
import bookmyconsultation.Doctor.service.TokenProvider;
import bookmyconsultation.Doctor.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import useronboarding.controller.Valid;

import java.io.IOException;
import java.util.List;

@RestController
public class DoctorController {

    @Autowired
    DoctorService doctorService;

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private TokenProvider tokenProvider;

    @Autowired
    private UserService userService;

    private static final Logger LOGGER = LoggerFactory.getLogger(DoctorController.class);

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE,value = "/doctors/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN') OR hasRole('ROLE_USER')")
    public ResponseEntity findDoctorById(@PathVariable(value = "id") String id){
        DoctorEntity doctorEntity= doctorService.getDoctorBasedOnId(id);

        return new ResponseEntity(doctorEntity, HttpStatus.OK);
    }

    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            value = "/doctors")
    @PreAuthorize("hasRole('ROLE_ADMIN') OR hasRole('ROLE_USER')")
    public ResponseEntity createDoctor(@Valid @RequestBody  DoctorDto doctorDto){

        DoctorDto doctorDtoResponse = doctorService.createDoctor(doctorDto);
        return new ResponseEntity(doctorDtoResponse, HttpStatus.CREATED);
    }

    @GetMapping(produces=MediaType.APPLICATION_JSON_VALUE,value="/doctors")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity getDoctorsByPage(String status,String speciality)
    {
        List<DoctorEntity> doctors = doctorService.getDoctorsByPage(status,speciality);
        System.out.println("doctors:::::::"+doctors);
        return new ResponseEntity(doctors,HttpStatus.OK);
    }



    @PostMapping(value = "/doctors/{doctorId}/documents")
    @PreAuthorize("hasRole('ROLE_ADMIN') OR hasRole('ROLE_USER')")
    public ResponseEntity<String> uploadFiles(@PathVariable("doctorId") String doctorId, @RequestParam MultipartFile[] files) throws IOException {
        doctorService.uploadFiles(doctorId, files);
        return ResponseEntity.ok().body("File(s) uploaded Successfully");
    }



    @PutMapping ("/doctors/{doctorId}/approve")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity approveDoctor(@PathVariable("doctorId") String doctorId ,@RequestBody ApproveDoctorDto approveDoctorDto){

        ActiveDoctorDto doctorResponse = doctorService.approveDoctor(doctorId,approveDoctorDto);

        return new ResponseEntity(doctorResponse,HttpStatus.OK);
    }

    @PutMapping ("/doctors/{doctorId}/reject")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity rejectDoctor(@PathVariable("doctorId") String doctorId ,@RequestBody ApproveDoctorDto approveDoctorDto){

        ActiveDoctorDto doctorResponse = doctorService.rejectDoctor(doctorId,approveDoctorDto);

        return new ResponseEntity(doctorResponse,HttpStatus.OK);
    }



}
