package bookmyconsultation.Doctor.repository;

import bookmyconsultation.Doctor.entity.DoctorEntity;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface DoctorDao extends MongoRepository<DoctorEntity,String>{

    @Query(value="{'status': ?0}")
    Page<DoctorEntity> findByStatus(String status, Pageable pageable);

    @Query(value="{'speciality': ?0}")
    Page<DoctorEntity> findBySpeciality(String speciality, Pageable pageable);

    @Query(value="{'status': ?0,'speciality': ?1}")
    Page<DoctorEntity> findByStatusAndSpeciality(String status,String speciality, Pageable pageable);
}