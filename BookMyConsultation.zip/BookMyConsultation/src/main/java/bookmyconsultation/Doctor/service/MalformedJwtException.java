package bookmyconsultation.Doctor.service;

public class MalformedJwtException extends Throwable {
}
