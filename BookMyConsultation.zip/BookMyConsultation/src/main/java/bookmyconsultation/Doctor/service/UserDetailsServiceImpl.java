package bookmyconsultation.Doctor.service;

import bookmyconsultation.Doctor.dto.User;
import bookmyconsultation.Doctor.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class UserDetailsServiceImpl implements UserService, UserDetailsService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    RestTemplate restTemplate;

    @Override
    public com.upgrad.course.demo.model.UserPrincipal loadUserByUsername(String id) throws UsernameNotFoundException {
        User user = userRepo
                .findById(id)
                .orElseThrow(() -> new UsernameNotFoundException("User name " + id + " does not exist"));
        return com.upgrad.course.demo.model.UserPrincipal.create(user);
    }

    @Override
    public List<User> getAllUsers() {
        return userRepo.findAll();
    }
}
