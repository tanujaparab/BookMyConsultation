package bookmyconsultation.Doctor.service;

import bookmyconsultation.Doctor.dto.ActiveDoctorDto;
import bookmyconsultation.Doctor.dto.ApproveDoctorDto;
import bookmyconsultation.Doctor.dto.DoctorDto;
import bookmyconsultation.Doctor.entity.DoctorEntity;
import bookmyconsultation.Doctor.exception.RecordNotFoundException;
import bookmyconsultation.Doctor.mapper.DoctorMapper;

import bookmyconsultation.Doctor.repository.DoctorDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import useronboarding.repository.S3Repository;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class DoctorServiceImpl implements DoctorService {

    @Autowired
    DoctorDao doctorDao;

    @Autowired
    ProducerService producerService;

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    S3Repository s3Repository;

    private String doctorIdGenerator() {
        UUID doctorId = UUID.randomUUID();
        String doctorIdStr = doctorId.toString();
        DoctorEntity doctorEntity = getDoctorDetailsBasedOnId(doctorIdStr);
        if(doctorEntity!=null)
            doctorIdGenerator();
        return doctorIdStr;
    }

    private DoctorEntity getDoctorDetailsBasedOnId(String doctorId) {
        try {
            DoctorEntity doctorEntity = doctorDao.findById(doctorId).get();
            if (doctorEntity != null)
                return doctorEntity;
        }catch (Exception e){}
        return null;
    }

    @Override
    public DoctorDto createDoctor(DoctorDto doctorDto) {
        DoctorEntity doctorEntity = DoctorMapper.convertDTOToEntity(doctorDto);
        doctorEntity.setId(doctorIdGenerator());
        doctorEntity = doctorDao.save(doctorEntity);
        DoctorDto DoctorDtoResponse = DoctorMapper.convertEntityToDTO(doctorEntity);
        producerService.publishDoctor(doctorEntity);
        return DoctorDtoResponse;
    }

    @Override
    public DoctorEntity getDoctorBasedOnId(String id) {
        Optional<DoctorEntity> doctor = Optional.ofNullable(doctorDao.findById(id)
                .orElseThrow(() -> new RecordNotFoundException
                        ("Details for Doctor[" + id + "] does not exist")));
        if(doctor.isPresent())
            return doctor.get();
        return null;
    }

    @Override
    public DoctorEntity updateDoctor(DoctorEntity doctor) {
        DoctorEntity savedDoctor = getDoctorBasedOnId(doctor.getId());
        savedDoctor.setId(doctor.getId());
        return doctorDao.save(savedDoctor);
    }


    @Override
    public List<DoctorEntity> getDoctorsByPage(String status,String speciality) {
        List<DoctorEntity> doctors = new ArrayList<DoctorEntity>();
        System.out.println("doctors::::service:::"+doctors);
        Pageable paging = PageRequest.of(0, 20, Sort.by("avgRating").descending());
        System.out.println("paging::::service:::"+status);
        System.out.println("paging::::service:::"+speciality);
        Page<DoctorEntity> pageDocs;
        if(status!=null && speciality!=null)
            pageDocs = doctorDao.findByStatusAndSpeciality(status,speciality,paging);
        else if(speciality!=null)
            pageDocs = doctorDao.findBySpeciality(speciality,paging);
        else
            pageDocs = doctorDao.findByStatus(status,paging);
        System.out.println("pageDocs::::service:::"+pageDocs);
        doctors = pageDocs.getContent();
        return doctors;
    }

    @Override
    public ActiveDoctorDto approveDoctor(String doctorId, ApproveDoctorDto approveDoctorDto) {
        return null;
    }

    @Override
    public ActiveDoctorDto approveDoctor(String doctorId, ApproveDoctorDto approveDoctorDto) {
        DoctorEntity savedDoctor = getDoctorBasedOnId(doctorId);

            DoctorDto doctorDto = DoctorMapper.convertEntityToDTO(savedDoctor);
            ActiveDoctorDto activeDoctorDto = DoctorMapper.convertDTOToActive(doctorDto,approveDoctorDto,"Active");
            DoctorEntity newDoctorEntity = DoctorMapper.convertActiveDTOToEntity(activeDoctorDto);
            doctorDao.save(newDoctorEntity);
            producerService.publishDoctor(newDoctorEntity);
            return activeDoctorDto;
    }

    @Override
    public ActiveDoctorDto rejectDoctor(String doctorId, ApproveDoctorDto approveDoctorDto) {
        DoctorEntity savedDoctor = getDoctorBasedOnId(doctorId);
        DoctorDto doctorDto = DoctorMapper.convertEntityToDTO(savedDoctor);
        ActiveDoctorDto activeDoctorDto = DoctorMapper.convertDTOToActive(doctorDto,approveDoctorDto,"Reject");
        DoctorEntity newDoctorEntity = DoctorMapper.convertActiveDTOToEntity(activeDoctorDto);
        doctorDao.save(newDoctorEntity);
        producerService.publishDoctor(newDoctorEntity);
        return activeDoctorDto;
    }

    @Override
    public void uploadFiles(String doctorId, MultipartFile[] files) throws IOException {
        for (MultipartFile file: files){
            s3Repository.uploadFiles(doctorId, file);
        }
    }

}
