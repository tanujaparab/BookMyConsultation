package bookmyconsultation.Doctor.service;

public class UnsupportedJwtException extends Throwable {
}
