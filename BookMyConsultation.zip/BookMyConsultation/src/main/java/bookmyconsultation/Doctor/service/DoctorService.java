package bookmyconsultation.Doctor.service;


import bookmyconsultation.Doctor.dto.ActiveDoctorDto;
import bookmyconsultation.Doctor.dto.ApproveDoctorDto;
import bookmyconsultation.Doctor.dto.DoctorDto;
import bookmyconsultation.Doctor.entity.DoctorEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface DoctorService {
    public DoctorDto createDoctor(DoctorDto doctorDto);

    public DoctorEntity getDoctorBasedOnId(String id);

    public DoctorEntity updateDoctor(DoctorEntity doctor);

    public List<DoctorEntity> getDoctorsByPage(String status,String speciality);

    public ActiveDoctorDto approveDoctor(String doctorId, ApproveDoctorDto approveDoctorDto);

    public ActiveDoctorDto rejectDoctor(String doctorId, ApproveDoctorDto approveDoctorDto);

    void uploadFiles(String doctorId, MultipartFile[] files) throws IOException;

}
