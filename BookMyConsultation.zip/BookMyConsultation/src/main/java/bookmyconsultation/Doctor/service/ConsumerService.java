package bookmyconsultation.Doctor.service;

import bookmyconsultation.Doctor.dto.AvgRating;
import bookmyconsultation.Doctor.entity.DoctorEntity;

import bookmyconsultation.Doctor.repository.DoctorDao;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import freemarker.template.TemplateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


@Service
public class ConsumerService {

    @Autowired
    DoctorService doctorService;

    @Autowired
    DoctorDao doctorDao;

    @KafkaListener(topics = "${consumer.topic}", groupId = "${group.id}", containerFactory = "concurrentKafkaListenerContainerFactory")
    public void listen(@Payload List<AvgRating> ratings) throws IOException, TemplateException, MessagingException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);

        List<AvgRating> doctorRatingList = mapper.readValue(ratings.toString(), new TypeReference<ArrayList<AvgRating>>() { });
        for(AvgRating rating : doctorRatingList){
            DoctorEntity doctorEntity = setRating(rating.getDoctorId(),rating.getAvgRating());
            doctorDao.save(doctorEntity);
        }
    }

    public DoctorEntity setRating(String doctorId,Double avgRating){
        DoctorEntity doctorEntity = doctorService.getDoctorBasedOnId(doctorId);
        doctorEntity.setAvgRating(avgRating);
        return doctorEntity;
    }


}
