package bookmyconsultation.Doctor.service;

public class ExpiredJwtException extends Throwable {
}
