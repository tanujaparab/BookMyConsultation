package bookmyconsultation.Doctor.entity;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Data
@Document(collection = "Doctor")
public class DoctorEntity {

    private String id;
    private String firstName;
    private String lastName;
    @Field(name="speciality")
    private String speciality = "GENERAL_PHYSICIAN";
    private String dob;
    private String mobile;
    private String emailId;
    private String pan;
    private String status;
    private String approvedBy;
    private String approverComments;
    private String registrationDate;
    private String verificationDate;
    private Double avgRating;
}
