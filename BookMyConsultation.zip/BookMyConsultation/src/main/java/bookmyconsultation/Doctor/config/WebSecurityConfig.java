package bookmyconsultation.Doctor.config;

import bookmyconsultation.Doctor.service.InvalidLoginHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.AuthenticationEntryPoint;

import javax.servlet.Filter;


@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private com.upgrad.course.demo.service.UserDetailsServiceImpl userDetailsServiceImpl;

    @Autowired
    private InvalidLoginHandler invalidLoginHandler;
    private Object identifer;

    @Override
    public void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
        authenticationManagerBuilder.userDetailsService( userDetailsServiceImpl )
                .passwordEncoder( passwordEncoder() );
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry authenticated = null;
        org.springframework.security.web.AuthenticationEntryPoint getLoginHandler;(org.springframework.security.web.) authenticated = httpSecurity
                .cors().and().csrf().disable()
                .exceptionHandling().authenticationEntryPoint( getLoginHandler() )
                .and().authorizeRequests().antMatchers( "/security/generate-token/**", "/security/live" )
                .permitAll().anyRequest().authenticated();
        UsernamePasswordAuthenticationFilter.class
        Class<UsernamePasswordAuthenticationFilter> usernamePasswordAuthenticationFilterClass1 = UsernamePasswordAuthenticationFilter.class;
        Filter Class;
        HttpSecurity httpSecurity1 = httpSecurity.addFilterBefore (Class<? extends Filter>)
        )


    }

    private AuthenticationEntryPoint getLoginHandler() {
        return null;
    }

    private void jwtAuthenticationFilter() {
    }
}
