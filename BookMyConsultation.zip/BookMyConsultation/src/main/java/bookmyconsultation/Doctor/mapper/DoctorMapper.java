package bookmyconsultation.Doctor.mapper;

import bookmyconsultation.Doctor.dto.ActiveDoctorDto;
import bookmyconsultation.Doctor.dto.ApproveDoctorDto;
import bookmyconsultation.Doctor.dto.DoctorDto;
import bookmyconsultation.Doctor.entity.DoctorEntity;


import java.text.SimpleDateFormat;
import java.util.Date;


public class DoctorMapper {


    public static DoctorEntity convertDTOToEntity(DoctorDto doctorDto) {
        DoctorEntity doctorEntity = new DoctorEntity();
        doctorEntity.setId(doctorDto.getId());
        doctorEntity.setFirstName(doctorDto.getFirstName());
        doctorEntity.setLastName(doctorDto.getLastName());
        doctorEntity.setMobile(doctorDto.getMobile());
        doctorEntity.setEmailId(doctorDto.getEmailId());
        doctorEntity.setPan(doctorDto.getPan());
        doctorEntity.setStatus("Pending");
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        doctorEntity.setRegistrationDate(formatter.format(date));
        doctorEntity.setDob(doctorDto.getDob());
        doctorEntity.setSpeciality(doctorDto.getSpeciality());
        doctorEntity.setAvgRating(doctorDto.getAvgRating());
        return doctorEntity;
    }

    public static ActiveDoctorDto convertDTOToActive(DoctorDto doctorDto, ApproveDoctorDto approveDoctorDto, String status) {
        ActiveDoctorDto activeDoctorDto = new ActiveDoctorDto();
        activeDoctorDto.setId(doctorDto.getId());
        activeDoctorDto.setFirstName(doctorDto.getFirstName());
        activeDoctorDto.setLastName(doctorDto.getLastName());
        activeDoctorDto.setMobile(doctorDto.getMobile());
        activeDoctorDto.setEmailId(doctorDto.getEmailId());
        activeDoctorDto.setPan(doctorDto.getPan());
        activeDoctorDto.setStatus(status);
        activeDoctorDto.setRegistrationDate(doctorDto.getRegistrationDate());
        activeDoctorDto.setDob(doctorDto.getDob());
        activeDoctorDto.setSpeciality(doctorDto.getSpeciality());
        activeDoctorDto.setApprovedBy(approveDoctorDto.getApprovedBy());
        activeDoctorDto.setApproverComments(approveDoctorDto.getApproverComments());
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        activeDoctorDto.setVerificationDate(formatter.format(date));
        activeDoctorDto.setAvgRating(doctorDto.getAvgRating());
        return activeDoctorDto;
    }

    public static DoctorDto convertEntityToDTO(DoctorEntity doctorEntity) {
        DoctorDto doctorDto = new DoctorDto();
        doctorDto.setId(doctorEntity.getId());
        doctorDto.setFirstName(doctorEntity.getFirstName());
        doctorDto.setLastName(doctorEntity.getLastName());
        doctorDto.setMobile(doctorEntity.getMobile());
        doctorDto.setEmailId(doctorEntity.getEmailId());
        doctorDto.setPan(doctorEntity.getPan());
        doctorDto.setStatus(doctorEntity.getStatus());
        doctorDto.setRegistrationDate(doctorEntity.getRegistrationDate());
        doctorDto.setDob(doctorEntity.getDob());
        doctorDto.setSpeciality(doctorEntity.getSpeciality());
        doctorDto.setAvgRating(doctorEntity.getAvgRating());
        return doctorDto;
    }

    public static DoctorEntity convertActiveDTOToEntity(ActiveDoctorDto doctorDto) {
        DoctorEntity doctorEntity = new DoctorEntity();
        doctorEntity.setId(doctorDto.getId());
        doctorEntity.setFirstName(doctorDto.getFirstName());
        doctorEntity.setLastName(doctorDto.getLastName());
        doctorEntity.setMobile(doctorDto.getMobile());
        doctorEntity.setEmailId(doctorDto.getEmailId());
        doctorEntity.setPan(doctorDto.getPan());
        doctorEntity.setStatus(doctorDto.getStatus());
        doctorEntity.setRegistrationDate(doctorDto.getRegistrationDate());
        doctorEntity.setDob(doctorDto.getDob());
        doctorEntity.setSpeciality(doctorDto.getSpeciality());
        doctorEntity.setApprovedBy(doctorDto.getApprovedBy());
        doctorEntity.setApproverComments(doctorDto.getApproverComments());
        doctorEntity.setVerificationDate(doctorDto.getVerificationDate());
        doctorEntity.setAvgRating(doctorDto.getAvgRating());
        return doctorEntity;
    }
}
