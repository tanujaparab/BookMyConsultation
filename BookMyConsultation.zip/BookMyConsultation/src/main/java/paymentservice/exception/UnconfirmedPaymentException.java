package paymentservice.exception;

//@ResponseStatus(HttpStatus.NOT_FOUND)
public class UnconfirmedPaymentException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public UnconfirmedPaymentException(String message) {
        super(message);
    }
}
