package paymentservice.exception.handler;



import appointmentservice.dto.CustomResponse;
import appointmentservice.exception.UnconfirmedPaymentException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import paymentservice.exception.CustomException;

import java.util.LinkedHashMap;
import java.util.Map;

@ControllerAdvice
public class CustomExceptionHandler {

    private static final String ERR_PAYMENT_PENDING ="ERR_PAYMENT_PENDING";

    @ExceptionHandler({CustomException.class})
    public ResponseEntity<CustomResponse> handleCustomException(Exception ex) {
        CustomResponse exceptionResponse = new CustomResponse(ex.getMessage(), HttpStatus.BAD_REQUEST.value());
        return new ResponseEntity<>(exceptionResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(UnconfirmedPaymentException.class)
    public final ResponseEntity<Object> handleUnconfirmedException(UnconfirmedPaymentException e){
        Map<String, Object> body=new LinkedHashMap<>();
        body.put("errorCode", ERR_PAYMENT_PENDING);
        body.put("errorMessage",e.getLocalizedMessage());
        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }

}