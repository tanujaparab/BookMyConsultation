package paymentservice.dto;

import appointmentservice.controller.AppointmentResponseDto;
import lombok.Data;

@Data
public class Appointment {

    private String id;

    private String doctorId;

    private String userId;

    private String timeSlot;

    private String status;

    private String appointmentDate;

    public void setUserName(String firstName) {
    }

    public void setUserEmailId(String emailId) {
    }

    public AppointmentResponseDto get() {
        return null;
    }
}
