package paymentservice.service;


import paymentservice.dto.Appointment;
import paymentservice.exception.CustomException;


public interface PaymentService {
    Appointment updatePayment(String id) throws CustomException, CustomException;
}
