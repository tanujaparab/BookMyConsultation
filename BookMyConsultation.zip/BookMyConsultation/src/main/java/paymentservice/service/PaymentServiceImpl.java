package paymentservice.service;


import appointmentservice.dto.User;
import appointmentservice.feign.SecurityProviderClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import paymentservice.dto.Appointment;
import paymentservice.exception.CustomException;
import paymentservice.feign.AppointmentServiceClient;

@Service
public class PaymentServiceImpl implements PaymentService{

    @Autowired
    AppointmentServiceClient appointmentServiceClient;

    @Autowired
    SecurityProviderClient securityProviderClient;

    @Value("${authUser}")
    private String authUser;

    @Value("${authPassword}")
    private String authPass;

    @Override
    public Appointment updatePayment(String id) throws CustomException {
        User user = new User(authUser,authPass);
        String token = securityProviderClient.SecurityProviderClient(user);
        Appointment appointment = null;
        try{
            appointment = appointmentServiceClient.confirmPaymentBasedOnId(token,id);
        }catch(Exception e){
            System.out.println("Exception::::" + e);
            throw new CustomException("Appointment Id {"+id+"} does not exist!");
        }
        return appointment;
    }


    }
