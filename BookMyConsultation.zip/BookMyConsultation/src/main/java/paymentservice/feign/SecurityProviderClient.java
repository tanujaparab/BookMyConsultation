package paymentservice.feign;


import feign.Headers;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import paymentservice.dto.User;


@FeignClient(name="BMC-GATEWAY")
public interface SecurityProviderClient {

    @RequestMapping(method = RequestMethod.POST, value = "/foodDelivery/security/generate-token", produces = "application/json")
    @Headers("Content-Type: application/json")
    String generateToken(@RequestBody User user);

}
