package paymentservice.feign;



import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import paymentservice.dto.Appointment;

@FeignClient(name="BMC-GATEWAY")
public interface AppointmentServiceClient {

    @RequestMapping(method = RequestMethod.PUT, value = "/appointments/{appointmentId}", produces = "application/json")
    Appointment confirmPaymentBasedOnId(@RequestHeader("Authorization") String token, @PathVariable(value = "appointmentId") String appointmentId);
    

}
