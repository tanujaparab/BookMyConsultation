package paymentservice.controller;


import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import paymentservice.dto.Appointment;
import paymentservice.exception.CustomException;
import paymentservice.service.PaymentService;

@RestController
public class PaymentController {

    @Autowired
    PaymentService paymentService;

    @SneakyThrows
    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE,value = "/payments")
    public Appointment updatePayment(@RequestParam(value ="appointmentId")String appointmentId) throws CustomException {
        Appointment appointment = paymentService.updatePayment(appointmentId);
        return appointment;
    }
}
