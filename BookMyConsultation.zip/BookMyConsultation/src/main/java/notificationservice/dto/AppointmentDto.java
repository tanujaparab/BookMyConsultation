package notificationservice.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.Date;

@Data
public class AppointmentDto {

    private String id;

    private Date appointmentDate;

    private LocalDateTime createdDate;

    private String doctorId;

    private String priorMedicalHistory;

    private String status;

    private String symptoms;

    private String timeSlot;

    private String userId;

    private String userEmailId;

    private String userName;

    private String doctorName;

}
