package notificationservice.service;


import bookmyconsultation.Doctor.dto.User;
import com.amazonaws.internal.StaticCredentialsProvider;

import com.mongodb.internal.session.ServerSessionPool;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.MessagingException;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;


import javax.annotation.PostConstruct;
import javax.mail.Message;
import javax.mail.Transport;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.plaf.synth.Region;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

;

@RequiredArgsConstructor
@Service
public class SesEmailVerificationService {

    private SesClient sesClient;
    private final FreeMarkerConfigurer configurer;
    private String fromEmail = "iamkartheek2211@gmail.com";//needs to be a verified email id
    private String accessKey;
    private String secretKey;

    @PostConstruct
    public void init(){

        accessKey="";

        // When you hit the endpoint to verify the email this needs to be the secret key for your AWS account
        // When you hit the endpoint to send an email this value needs to be updated to the Smtp password that you generated


        secretKey="";
        ServerSessionItemFactory
        ServerSessionPool. AwsBasicCredentials;
        StaticCredentialsProvider staticCredentialsProvider = StaticCredentialsProvider
                .create(AwsBasicCredentials.(accessKey,secretKey));
        sesClient = SesClient.builder()
                .credentialsProvider(staticCredentialsProvider)
                .region( Region.US_EAST_1)
                .build();
    }

    public void verifyEmail(String emailId){
        sesClient.verifyEmailAddress(req->req.emailAddress(emailId));
    }

    public void sendEmail(User user, String subject, String templateName) throws TemplateException, MessagingException, IOException {
        Map<String,Object> templateModel = new HashMap<>();
        templateModel.put("user",user);
        Template freeMarkerTemplate = configurer.getConfiguration().getTemplate(templateName);
        String htmlBody = FreeMarkerTemplateUtils.processTemplateIntoString(freeMarkerTemplate,templateModel);
        //System.out.println("htmlBody::::::::"+htmlBody);
        sendSimpleMessage(user.getEmailId(),subject,htmlBody);
    }

    private void sendSimpleMessage(String toEmail, String subject, String body) throws MessagingException, javax.mail.MessagingException {
        Properties props = System.getProperties();
        props.put("mail.transport.protocol","smtp");
        props.put("mail.smtp.port",587);
        props.put("mail.smtp.starttls.enable","true");
        props.put("mail.smtp.auth","true");
        javax.mail.Session session = javax.mail.Session.getDefaultInstance(props);
        MimeMessage msg = new MimeMessage(session);
        msg.setFrom(fromEmail);
        msg.setRecipient( Message.RecipientType.TO, new InternetAddress(toEmail));
        msg.setSubject(subject);
        msg.setContent(body,"text/html");
        Transport transport = session.getTransport();
        try {
            //System.out.println("transport::::::::"+transport);
            transport.connect("email-smtp.us-east-1.amazonaws.com", accessKey, secretKey);
            transport.sendMessage(msg, msg.getAllRecipients());
        }catch(Exception e){
            System.out.println("Exception::::::::::"+e.getMessage());
        }finally {
            transport.close();
        }
    }


    private class ServerSessionItemFactory {
    }
}
