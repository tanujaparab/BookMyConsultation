package notificationservice.service;

import bookmyconsultation.Doctor.dto.DoctorDto;
import bookmyconsultation.Doctor.dto.User;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import freemarker.template.TemplateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.MessagingException;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


@Service
public class ConsumerService {

    @Autowired
    SesEmailVerificationService verifyEmail;


    @KafkaListener(topics = "${consumer.topic}", groupId = "${group.id}", containerFactory = "concurrentKafkaListenerContainerFactory")
    public void listen(@Payload List<DoctorDto> doctors) throws IOException, TemplateException, MessagingException {
        System.out.println("doctors::::::::tostring"+doctors.toString());
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);

        List<DoctorDto> doctorList = mapper.readValue(doctors.toString(), new TypeReference<ArrayList<DoctorDto>>() { });
        for(DoctorDto dto : doctorList){
            if(!dto.getStatus().isEmpty()){
                System.out.println("doctors::::::::"+dto.getFirstName());
                User user = new User();
                user.setUserName(dto.getFirstName()+" "+dto.getLastName());
                user.setEmailId(dto.getEmailId());
                verifyEmail.sendEmail(user,"Doctor "+dto.getStatus(),"doctor_"+dto.getStatus()+".ftl");
            }

        }
    }


}
