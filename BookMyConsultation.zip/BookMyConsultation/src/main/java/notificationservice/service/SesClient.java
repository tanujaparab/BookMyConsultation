package notificationservice.service;

import com.amazonaws.auth.presign.PresignerParams;

public class SesClient {
    public static PresignerParams builder() {
        return null;
    }
}
