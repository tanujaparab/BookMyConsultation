package notificationservice.service;

import appointmentservice.dto.AppointmentDto;
import bookmyconsultation.Doctor.dto.User;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import freemarker.template.TemplateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.MessagingException;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class AppointmentConsumerService {

    @Autowired
    SesEmailVerificationService verifyEmail;


    @KafkaListener(topics = "${appointment.consumer.topic}", groupId = "${appointment.group.id}", containerFactory = "concurrentKafkaListenerContainerFactory")
    public void listen(@Payload List<AppointmentDto> appointments) throws IOException, TemplateException, MessagingException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);

        List<AppointmentDto> appointmentDtos = mapper.readValue(appointments.toString(), new TypeReference<ArrayList<AppointmentDto>>() { });
        for(AppointmentDto dto : appointmentDtos){
            User user = new User();
            user.setUserName(dto.getUserName());
            user.setEmailId(dto.getUserEmailId());
            verifyEmail.sendEmail(user,"User confirmed","user_Confirmed.ftl");
        }
    }
}
