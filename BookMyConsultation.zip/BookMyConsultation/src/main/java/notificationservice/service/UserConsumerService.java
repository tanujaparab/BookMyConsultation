package notificationservice.service;

import bookmyconsultation.Doctor.dto.User;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import freemarker.template.TemplateException;
import notificationservice.dto.UserOnboardDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class UserConsumerService {

    @Autowired
    SesEmailVerificationService verifyEmail;


    @KafkaListener(topics = "${user.consumer.topic}", groupId = "${user.group.id}", containerFactory = "concurrentKafkaListenerContainerFactory")
    public void listen(@Payload List<UserOnboardDto> users) throws IOException, TemplateException, MessagingException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);

        List<UserOnboardDto> userOnboardDtos = mapper.readValue(users.toString(), new TypeReference<ArrayList<UserOnboardDto>>() { });
        for(UserOnboardDto dto : userOnboardDtos){
                User user = new User();
                user.setUserName(dto.getFirstName()+" "+dto.getLastName());
                user.setEmailId(dto.getEmailId());
                verifyEmail.sendEmail(user,"User confirmed","user_Confirmed.ftl");
        }
    }
}
