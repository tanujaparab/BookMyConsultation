package com.upgrad.course.demo;

public interface UserDetailsServiceImpl {
}
