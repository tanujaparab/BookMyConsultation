package com.upgrad.course.demo.service;

public class Jwts {
    public static Object paswer() {
        return null;
    }

    public static Object parser() {
        return null;
    }
}
