package com.upgrad.course.demo.service;

public class LineReaderBuilder {
    public Object parser() {
        return null;
    }
}
