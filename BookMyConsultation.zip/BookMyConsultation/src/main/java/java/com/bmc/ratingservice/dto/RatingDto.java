package java.com.bmc.ratingservice.dto;

import lombok.Data;


@Data
public class RatingDto {
    private String doctorId;
    private int rating;
}
