package java.com.bmc.ratingservice.dto;

import lombok.Data;

@Data
public class AvgRating {
    private String doctorId;
    private Double avgRating;
}
