package java.com.bmc.ratingservice.service;


import java.com.bmc.ratingservice.dto.RatingDto;
import java.com.bmc.ratingservice.entity.Rating;

public interface RatingService {

    Rating saveRating(RatingDto ratingDto);
}
