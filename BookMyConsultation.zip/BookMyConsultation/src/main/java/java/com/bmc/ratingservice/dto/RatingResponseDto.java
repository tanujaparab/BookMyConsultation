package java.com.bmc.ratingservice.dto;

import lombok.Data;

@Data
public class RatingResponseDto {

    private String id;
    private String doctorId;
    private int rating;
}
