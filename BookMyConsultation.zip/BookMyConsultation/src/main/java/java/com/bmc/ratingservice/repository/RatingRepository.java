package java.com.bmc.ratingservice.repository;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.com.bmc.ratingservice.entity.Rating;
import java.util.List;


@Repository
public interface RatingRepository extends MongoRepository<Rating, String> {

    List<Rating> findByDoctorId(String doctorId);
}
