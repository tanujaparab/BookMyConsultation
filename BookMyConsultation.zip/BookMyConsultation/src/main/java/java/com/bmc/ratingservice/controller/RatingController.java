package java.com.bmc.ratingservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.com.bmc.ratingservice.dto.RatingDto;
import java.com.bmc.ratingservice.dto.RatingResponseDto;
import java.com.bmc.ratingservice.entity.Rating;
import java.com.bmc.ratingservice.service.RatingService;

@RestController
public class RatingController {

    @Autowired
    RatingService ratingService;

    @PostMapping(consumes= MediaType.APPLICATION_JSON_VALUE,
                    produces = MediaType.APPLICATION_JSON_VALUE,
                        value = "/ratings")
    public RatingResponseDto saveResponse(@RequestBody RatingDto ratingDto){
        Rating rating = ratingService.saveRating(ratingDto);
        RatingResponseDto ratingResponseDto = new RatingResponseDto();
        ratingResponseDto.setRating(rating.getRating());
        ratingResponseDto.setId(rating.getId());
        ratingResponseDto.setDoctorId(rating.getDoctorId());
        return ratingResponseDto;
    }
}
