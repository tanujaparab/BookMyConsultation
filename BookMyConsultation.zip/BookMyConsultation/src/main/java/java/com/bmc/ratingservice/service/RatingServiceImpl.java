package java.com.bmc.ratingservice.service;


import bookmyconsultation.Doctor.dto.AvgRating;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.com.bmc.ratingservice.dto.RatingDto;
import java.com.bmc.ratingservice.entity.Rating;
import java.com.bmc.ratingservice.repository.RatingRepository;
import java.util.List;
import java.util.UUID;

@Service
public class RatingServiceImpl implements RatingService {

    @Autowired
    RatingRepository ratingRepository;

    @Autowired
    ProducerService producerService;

    @Override
    public Rating saveRating(RatingDto ratingDto) {
        Rating rating = new Rating();
        rating.setRating(ratingDto.getRating());
        rating.setDoctorId(ratingDto.getDoctorId());
        rating.setId(ratingIdGenerator());
        Rating savedRating  = ratingRepository.save(rating);
        AvgRating avgRating = avgRatingCalculator(ratingDto.getDoctorId());
        producerService.publishRating(avgRating);
        return savedRating;
    }

    private Rating checkRatingDetailsBasedOnId(String ratingId) {
        try {
            Rating rating = ratingRepository.findById(ratingId).get();
            if (rating != null)
                return rating;
        }catch (Exception e){}
        return null;
    }

    private String ratingIdGenerator() {
        UUID ratingId = UUID.randomUUID();
        String ratingIdStr = ratingId.toString();
        Rating rating = checkRatingDetailsBasedOnId(ratingIdStr);
        if(rating!=null)
            ratingIdGenerator();
        return ratingIdStr;
    }

    private AvgRating avgRatingCalculator(String doctorId){
        List<Rating> ratingList = ratingRepository.findByDoctorId(doctorId);
        Double averageRating = ratingList.stream()
                .mapToDouble(Rating::getRating)
                .average()
                .getAsDouble();
        AvgRating avgRating =  new AvgRating();
        avgRating.setDoctorId(doctorId);
        avgRating.setAvgRating(averageRating);
        return avgRating;
    }

}
