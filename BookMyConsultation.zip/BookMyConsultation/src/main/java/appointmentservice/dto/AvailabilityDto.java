package appointmentservice.dto;

import lombok.Data;

import java.util.HashMap;
import java.util.List;

@Data
public class AvailabilityDto {

    HashMap<String,List<String>> availabilityMap = new HashMap<String, List<String>>();


}
