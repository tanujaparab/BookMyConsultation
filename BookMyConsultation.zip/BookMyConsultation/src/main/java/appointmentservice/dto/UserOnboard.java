package appointmentservice.dto;

import lombok.Data;

@Data
public class UserOnboard {

    private String id;
    private String firstName;
    private String lastName;
    private String dob;
    private String mobile;
    private String emailId;
    private String creationDate;

}
