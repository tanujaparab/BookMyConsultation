package appointmentservice.dto;

import appointmentservice.entities.Medicine;

import lombok.Data;

import java.util.List;

@Data
public class PrescriptionDto {
    private String id;
    private String userId;
    private String doctorId;
    private String doctorName;
    private String appointmentId;
    private String diagnosis;
    private List<Medicine> medicineList;
}
