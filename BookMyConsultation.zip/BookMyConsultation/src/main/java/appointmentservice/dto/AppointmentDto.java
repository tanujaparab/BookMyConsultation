package appointmentservice.dto;

import lombok.Data;

@Data
public class AppointmentDto {

    private String doctorId;
    private String userId;
    private String appointmentDate;
    private String timeSlot;

    public String getUserName() {
        return null;
    }

    public String getUserEmailId() {
        return null;
    }
}
