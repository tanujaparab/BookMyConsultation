package appointmentservice.dto;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class AvailabilityResponseDto {
    private String doctorId;
    private Map<String, List<String>> availabilityMap;
}
