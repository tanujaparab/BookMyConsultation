package appointmentservice.dto;

import lombok.Data;

@Data
public interface UsAppointmentResponseDto {

        String id = null;

        String doctorId = null;

        String userId = null;

        String timeSlot = null;

        String status = null;

        String appointmentDate = null;


    }

