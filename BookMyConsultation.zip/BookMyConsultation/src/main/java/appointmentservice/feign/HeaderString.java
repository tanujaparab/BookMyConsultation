package appointmentservice.feign;

public @interface HeaderString {
}
