package appointmentservice.feign;


import appointmentservice.entities.Doctor;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name = "BMC-GATEWAY")
public interface DoctorServiceClient {

    @RequestMapping(method = RequestMethod.GET, value = "/doctors/{id}", produces = "application/json")
    Doctor findDoctorById(@RequestHeader("Authorization") String token, @PathVariable(value = "id") String id);


}
