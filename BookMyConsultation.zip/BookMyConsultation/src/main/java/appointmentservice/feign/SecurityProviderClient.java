package appointmentservice.feign;

import appointmentservice.dto.User;

import feign.Headers;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@FeignClient(name = "BMC-GATEWAY")
public interface SecurityProviderClient {

    @RequestMapping(method = RequestMethod.POST, value = "/foodDelivery/security/generate-token", produces = "application/json")
    @Headers("Content-Type: application/json")default
    String generateToken() {
        return generateToken(  );
    }

    default String generateToken(User user) {
        return null;
    }

    private void s("Content-Type: application/json") {
        
    }

    String SecurityProviderClient(User user);
}
