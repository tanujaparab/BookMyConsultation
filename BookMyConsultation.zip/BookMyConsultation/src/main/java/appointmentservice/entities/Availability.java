package appointmentservice.entities;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
public class Availability {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
    private long id;
    @Column(name="available_date",nullable=true)
    private String availabledate;
    @Column(name="doctor_id",nullable=true,length = 255)
    private String doctorId;
    @Column(name="is_booked",nullable=false,length = 1)
    private Character isBooked;
    @Column(name="time_slot",nullable=true,length = 255)
    private String timeSlot;

}
