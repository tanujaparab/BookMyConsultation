package appointmentservice.entities;

import lombok.Data;

@Data
public class Doctor {
    private String id;
    private String firstName;
    private String lastName;
    private String speciality;
    private String dob;
    private String mobile;
    private String emailId;
    private String pan;
    private String status;
    private String approvedBy;
    private String approverComments;
    private String registrationDate;
    private String verificationDate;
}




