package appointmentservice.entities;

import lombok.Data;

@Data
public class Medicine {
    public String name;
    public String dosage;
    public String frequency;
    public String remarks;
}
