package appointmentservice.entities;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Data
public class Appointment {

    @Id
    @Column(name="appointment_id",length = 64)
    private String id;

    @Column(name="appointment_date")
    private Date appointmentDate;

    @Column(name="created_date")
    private LocalDateTime createdDate;

    @Column(name="doctor_id")
    private String doctorId;

    @Column(name="prior_medical_history")
    private String priorMedicalHistory;

    @Column(name="status")
    private String status;

    @Column(name="symptoms")
    private String symptoms;

    @Column(name="time_slot")
    private String timeSlot;

    @Column(name="user_id")
    private String userId;

    @Column(name="user_email_id")
    private String userEmailId;

    @Column(name="user_name")
    private String userName;

    @Column(name="doctor_name")
    private String doctorName;

}
