package appointmentservice.controller;

public class AppointmentResponseDto {
    private String doctorId;

    public String getStatus() {
        return null;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public void setUserId(String userId) {
    }

    public void setAppointmentDate(String strDate) {
    }

    public void setTimeSlot(String timeSlot) {
    }

    public void setStatus(String status) {
    }

    public void setId(String id) {
    }
}
