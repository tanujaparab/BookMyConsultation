package appointmentservice.controller;

import appointmentservice.dto.AppointmentDto;
import appointmentservice.dto.AvailabilityDto;
import appointmentservice.dto.AvailabilityResponseDto;
import appointmentservice.dto.PrescriptionDto;
import appointmentservice.entities.Prescription;
import appointmentservice.exception.CustomException;
import appointmentservice.mapper.ModelMapper;
import appointmentservice.service.AvailabiltyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.List;

@RestController
public class AvailabilityController {

    @Autowired
    AvailabiltyService availabiltyService;

    @Autowired
    ModelMapper modelMapper;

    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            value = "/doctor/{doctorId}/availability")
    public ResponseEntity createAvailableSlots(@RequestBody AvailabilityDto availabilityDto, @PathVariable (value = "doctorId") String doctorId) throws CustomException, CustomException {
        availabiltyService.createAvailableSlots(availabilityDto,doctorId);
        return new ResponseEntity("Created Successfully", HttpStatus.OK);
    }

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE,value = "/doctor/{doctorId}/availability")
    public ResponseEntity getAvailableSlots( @PathVariable (value = "doctorId") String doctorId) throws CustomException {
        AvailabilityResponseDto availabilityResponseDto = availabiltyService.getAvailableSlots(doctorId);
        return new ResponseEntity(availabilityResponseDto, HttpStatus.OK);
    }

    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            value = "/appointments")
    public ResponseEntity createAppointment(@RequestBody AppointmentDto appointmentDto) throws CustomException, ParseException {
       String appointmentId =  availabiltyService.createAppointment(appointmentDto);
        return new ResponseEntity(appointmentId, HttpStatus.OK);
    }

    @PutMapping(produces = MediaType.APPLICATION_JSON_VALUE,
            value = "/appointments/{appointmentId}")
    public ResponseEntity confirmPayment(@PathVariable (value = "appointmentId") String appointmentId) throws CustomException, ParseException {
        AppointmentResponseDto appointmentResponseDto = availabiltyService.confirmPayment(appointmentId);
        return new ResponseEntity(appointmentResponseDto, HttpStatus.OK);
    }



    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE,value = "/appointments/{appointmentId}")
    public ResponseEntity getAvailableAppointment( @PathVariable (value = "appointmentId") String appointmentId) throws CustomException {
        AppointmentResponseDto appointmentResponseDto = availabiltyService.getAppointmentDetailsBasedOnId(appointmentId);
        return new ResponseEntity(appointmentResponseDto, HttpStatus.OK);
    }

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE,value = "/users/{userId}/appointments")
    public ResponseEntity getAllAppointmentsBasedonUser(@PathVariable (value = "userId") String userId) throws CustomException {
        List<AppointmentResponseDto> appointmentResponses = availabiltyService.getAppointmentsBasedonUser(userId);
        return new ResponseEntity(appointmentResponses,HttpStatus.OK);
    }

    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            value = "/prescriptions")
    public ResponseEntity createPrescriptions(@RequestBody PrescriptionDto prescriptionDto) throws CustomException {
        Prescription prescription = modelMapper.map(prescriptionDto,Prescription.class);
        Prescription savedPrescription = availabiltyService.createPrescription(prescription);
        Prescription savedPrescriptionDto = modelMapper.map(savedPrescription,PrescriptionDto.class);
        return new ResponseEntity(savedPrescriptionDto, HttpStatus.OK);
    }
}
