package appointmentservice.service;

import appointmentservice.controller.AppointmentResponseDto;
import appointmentservice.dto.*;
import appointmentservice.entities.Availability;
import appointmentservice.entities.Doctor;
import appointmentservice.entities.Prescription;
import appointmentservice.exception.CustomException;

import appointmentservice.exception.UnconfirmedPaymentException;
import appointmentservice.feign.DoctorServiceClient;
import appointmentservice.feign.SecurityProviderClient;
import appointmentservice.feign.UserServiceClient;
import appointmentservice.mapper.AppointmentMapper;
import appointmentservice.mapper.ModelMapper;
import appointmentservice.repository.AppointmentRepository;
import appointmentservice.repository.AvailabilityRepository;
import appointmentservice.repository.PrescriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import paymentservice.dto.Appointment;

import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AvailabilityServiceImpl implements  AvailabiltyService{

    @Autowired
    DoctorServiceClient doctorServiceClient;

    @Autowired
    PrescriptionRepository prescriptionRepository;

    @Autowired
    SecurityProviderClient securityProviderClient;

    @Autowired
    AvailabilityRepository availabilityRepository;

    @Autowired
    AppointmentRepository appointmentRepository;

    @Autowired
    UserServiceClient userServiceClient;

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    ProducerService producerService;

    @Value("${authUser}")
    private String authUser;


    @Value("${authPassword}")
    private String authPass;

    @Override
    @Transactional
    public void createAvailableSlots(String doctorId) throws CustomException {
        createAvailableSlots( doctorId );
    }

    @Override
    @Transactional
    public void createAvailableSlots() throws CustomException {
        createAvailableSlots( );
    }

    @Override
    @Transactional
    public void createAvailableSlots(AvailabilityDto availabilityDto, String doctorId) throws CustomException {
        AvailabilityResponseDto availabilityResponseDto = getAvailableSlots(doctorId);
        System.out.println("AvailabilityResponseDto::::::"+availabilityResponseDto);
        if(availabilityResponseDto.getAvailabilityMap().isEmpty()){
            Map<String, List<String>> availabilityMap = availabilityDto.getAvailabilityMap();
            availabilityMap.forEach((k, v) -> {
                v.forEach((temp) -> {
                    Availability newAvailability = new Availability();
                    System.out.println(temp);
                    newAvailability.setAvailabledate(k);
                    newAvailability.setDoctorId(doctorId);
                    newAvailability.setTimeSlot(temp);
                    newAvailability.setIsBooked('f');
                    Availability save = availabilityRepository.save( newAvailability );
                });
            });
        }else{
            deleteAvailableSlots(doctorId);
            createAvailableSlots( doctorId,getAvailabilityDto( availabilityDto ));
        }
    }

    private void createAvailableSlots(String doctorId, AvailabilityDto availabilityDto) {
    }

    private AvailabilityDto getAvailabilityDto(AvailabilityDto availabilityDto) {
        return availabilityDto;
    }

    private Doctor checkDoctorId(String id) throws CustomException {
        User user = new User(authUser,authPass);
        String token = securityProviderClient.SecurityProviderClient(user);
        Doctor doctor = null;
        try{
            doctor =doctorServiceClient.findDoctorById(token,id);
        }catch(Exception e){
            System.out.println("Exception::::" + e);
            throw new CustomException( Optional.of( new StringBuilder().append( "Doctor Id {" ).append( id ).append( "} does not exist!" ).toString() ) );
        }
        return doctor;
    }

    private UserOnboard checkUserId(String id) throws CustomException {
        User user = new User(authUser,authPass);
        String token = securityProviderClient.SecurityProviderClient(user);
        UserOnboard userOnboard = null;
        try{
            userOnboard =userServiceClient.getUserBasedOnId(token,id);
        }catch(Exception e){
            System.out.println("Exception::::" + e);
            throw new CustomException( Optional.of( "User Id {" + id + "} does not exist!" ) );
        }
        return userOnboard;
    }

    @Override
    public AvailabilityResponseDto getAvailableSlots(String doctorId) throws CustomException {
        Doctor doctor = checkDoctorId(doctorId);
        if (doctor != null) {
            List<Availability> availabilityList = availabilityRepository.findAvailabilityByDoctorId(doctorId);
            List<String> availDateList = availabilityList.stream().map(x -> x.getAvailabledate()).collect(Collectors.toList());
            Map<String, List<String>> availabilityMap = new HashMap<>();
            for (String date : availDateList) {
                List<String> availSlotList = availabilityList.stream().map(x -> x.getTimeSlot()).collect(Collectors.toList());
                availabilityMap.put(date, availSlotList);
            }
            AvailabilityResponseDto response = new AvailabilityResponseDto();
            response.setDoctorId(doctorId);
            response.setAvailabilityMap(availabilityMap);
            return response;
        }

        return null;
    }

    @Override
    public List<Availability> getAllAvailableSlots() {
        return null;
    }

    public void deleteAvailableSlots(String doctorId) throws CustomException {
        availabilityRepository.deleteAvailabilitiesByDoctorId(doctorId);
    }
    @Override
    public String createAppointment(AppointmentDto appointmentDto) throws ParseException, CustomException {
        paymentservice.dto.Appointment appointment = AppointmentMapper.convertDTOToEntity(appointmentDto);
        String appointmentIdStr = appointmentIdGenerator();
        UserOnboard user = checkUserId(appointment.getUserId());
        appointment.setUserName(user.getFirstName());
        appointment.setUserEmailId(user.getEmailId());
        appointment.setId(appointmentIdStr);
        appointment.setStatus("Pending Payment");
        producerService.publishAppointment(appointment);
        return appointmentIdStr;
    }

    public AppointmentResponseDto confirmPayment(String appointmentId) throws ParseException, CustomException {
        try{
            Appointment appointment = appointmentRepository.findById(appointmentId).get();
            if(appointment.get() !=null) {
                appointment.get().setStatus("Confirmed");
                appointmentRepository.save(appointment);
                AppointmentResponseDto appointmentResponseDto = AppointmentMapper.convertEntityToDto(appointment);
                return appointmentResponseDto;
            }
        }catch(Exception e){
        throw new CustomException( Optional.of( "Appointment does not exist" ) );
    }
        return null;
    }

    @Override
    public List<AppointmentResponseDto> getAppointmentsBasedonUser(String userId) throws CustomException {
        UserOnboard userOnboard = checkUserId(userId);
        if (userOnboard != null) {
            List<Appointment> appointments = appointmentRepository.findAvailabilityByUserId(userId);
            System.out.println("appointments:::::" + appointments);
            List<AppointmentResponseDto> appointmentResponses = new ArrayList<>();
            for (Appointment appointment : appointments) {
                AppointmentResponseDto appointmentResponseDto = AppointmentMapper.convertEntityToDto(appointment);
                appointmentResponses.add(appointmentResponseDto);
            }
            System.out.println("appointmentResponses:::::" + appointmentResponses);
            return appointmentResponses;
        }
        return null;
    }

    @Override
    public Prescription createPrescription(Prescription prescription) throws CustomException {
        AppointmentResponseDto response = getAppointmentDetailsBasedOnId(prescription.getAppointmentId());
        Prescription savedPrescription;
        if(response!=null) {
            if("Confirmed".equals(response.getStatus())) {
                savedPrescription = prescriptionRepository.save(prescription);
                return savedPrescription;
            }
            throw new UnconfirmedPaymentException("Prescription cannot be issued since the payment status is pending");
        }
        throw new CustomException("Appointment not present");
    }

    @Override
    public void createAvailableSlots(AvailabilityDto availabilityDto, String doctorId) throws CustomException {
        
    }

    @Override
    public AppointmentResponseDto getAppointmentDetailsBasedOnId(String appointmentId) throws CustomException {
            try{
                Appointment appointment = appointmentRepository.findById(appointmentId).get();
                AppointmentResponseDto response = AppointmentMapper.convertEntityToDto(appointment);
                return response;
            }catch(Exception e){
                throw new CustomException( (Object) "Appointment does not exist" );
            }
    }

    private AppointmentResponseDto checkAppointmentDetailsBasedOnId(String appointmentId) {
            try {
                Appointment appointment = appointmentRepository.findById(appointmentId).get();
                AppointmentResponseDto response = AppointmentMapper.convertEntityToDto(appointment);
                if (appointment != null)
                    return response;
            }catch (Exception e){}
        return null;
    }

    private String appointmentIdGenerator() throws CustomException {
        UUID appointmentId = UUID.randomUUID();
        String appointmentIdStr = appointmentId.toString();
        AppointmentResponseDto appointment =checkAppointmentDetailsBasedOnId(appointmentIdStr);
        if(appointment!=null)
            appointmentIdGenerator();
        return appointmentIdStr;
    }

}
