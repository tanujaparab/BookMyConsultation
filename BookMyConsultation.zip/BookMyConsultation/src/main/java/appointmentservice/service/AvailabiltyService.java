package appointmentservice.service;

import appointmentservice.controller.AppointmentResponseDto;
import appointmentservice.dto.AppointmentDto;
import appointmentservice.dto.AvailabilityDto;
import appointmentservice.dto.AvailabilityResponseDto;
import appointmentservice.entities.Availability;
import appointmentservice.entities.Prescription;
import appointmentservice.exception.CustomException;
import org.springframework.transaction.annotation.Transactional;


import java.text.ParseException;
import java.util.List;

public interface AvailabiltyService {

    @Transactional
    void createAvailableSlots(String doctorId) throws CustomException;

    @Transactional
    void createAvailableSlots() throws CustomException;

    void createAvailableSlots(AvailabilityDto availabilityDto, String doctorId) throws CustomException;

    AppointmentResponseDto getAppointmentDetailsBasedOnId(String appointmentId) throws CustomException;

    AvailabilityResponseDto getAvailableSlots(String id) throws CustomException;

    List<Availability> getAllAvailableSlots();


    List<AppointmentResponseDto> getAppointmentsBasedonUser(String userId) throws CustomException;

    Prescription createPrescription(Prescription prescription) throws CustomException;

    AppointmentResponseDto confirmPayment(String appointmentId) throws ParseException, CustomException;

    default String createAppointment() {
        return createAppointment(  );
    }

    default String createAppointment(AppointmentDto appointmentDto) throws ParseException, CustomException {
        return null;
    }
}
