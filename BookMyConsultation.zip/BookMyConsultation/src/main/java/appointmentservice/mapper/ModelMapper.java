package appointmentservice.mapper;

import appointmentservice.dto.PrescriptionDto;
import appointmentservice.entities.Prescription;
import useronboarding.dto.UserOnBoardDto;
import useronboarding.entity.UserOnboarding;

public class ModelMapper {
    public Prescription map(PrescriptionDto prescriptionDto, Class<Prescription> prescriptionClass) {
        return null;
    }

    public Prescription map(Prescription savedPrescription, Class<PrescriptionDto> prescriptionDtoClass) {
        return savedPrescription;
    }

    public UserOnboarding map(UserOnBoardDto userOnBoardDto, Class<UserOnboarding> userOnboardingClass) {
        return null;
    }

    public UserOnBoardDto map(UserOnboarding user, Class<UserOnBoardDto> userOnBoardDtoClass) {
        return null;
    }
}
