package appointmentservice.mapper;




import appointmentservice.controller.AppointmentResponseDto;
import appointmentservice.dto.AppointmentDto;
import paymentservice.dto.Appointment;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AppointmentMapper {

    public static Appointment convertDTOToEntity(AppointmentDto appointmentDto) throws ParseException {
        Appointment appointmentEntity = new Appointment();
        appointmentEntity.setDoctorId(appointmentDto.getDoctorId());
        appointmentEntity.setUserId(appointmentDto.getUserId());
        Object appointmentDtoo = null;
        assert appointmentDtoo != null;
        String appointmentDate = appointmentDtoo.getAppointmentDate();
        Date date=new SimpleDateFormat("yyyy-MM-dd").parse(appointmentDate);
        appointmentEntity.setAppointmentDate( String.valueOf( date ) );
        appointmentEntity.setTimeSlot(appointmentDto.getTimeSlot());
           return appointmentEntity;
    }


    public static AppointmentResponseDto convertEntityToDto(Appointment appointment) {
        AppointmentResponseDto appointmentResponseDto = new AppointmentResponseDto();
        appointmentResponseDto.setDoctorId(appointment.getDoctorId());
        appointmentResponseDto.setUserId(appointment.getUserId());
        String date=appointment.getAppointmentDate();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String strDate = dateFormat.format(date);
        appointmentResponseDto.setAppointmentDate(strDate);
        appointmentResponseDto.setTimeSlot(appointment.getTimeSlot());
        appointmentResponseDto.setStatus(appointment.getStatus());
        appointmentResponseDto.setId(appointment.getId());
        return appointmentResponseDto;
    }



}
