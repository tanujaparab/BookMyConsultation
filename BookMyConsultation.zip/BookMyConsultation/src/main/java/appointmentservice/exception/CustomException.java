package appointmentservice.exception;

public class CustomException extends Exception{
    public CustomException(String s) {
    }

    public CustomException(String message) {
            super(message;
    }

    public CustomException(String appointment_does_not_exist) {
    }

    public CustomException(String s) {
    }

    public CustomException(String s) {

    }

    public CustomException(String toString) {

    }

    public CustomException(Object s) {


    }
}

