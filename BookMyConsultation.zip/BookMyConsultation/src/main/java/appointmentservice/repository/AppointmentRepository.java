package appointmentservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import paymentservice.dto.Appointment;

import java.util.List;
import java.util.Optional;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment,String> {
     List<Appointment> findAvailAabilityByUserId(String userId);

    List<Appointment> findAvailabilityByUserId(String userId);

    Optional<Appointment> findById(String appointmentId);
}
