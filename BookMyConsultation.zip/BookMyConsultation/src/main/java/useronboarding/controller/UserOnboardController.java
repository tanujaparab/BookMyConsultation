package useronboarding.controller;


import appointmentservice.mapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import useronboarding.dto.UserOnBoardDto;
import useronboarding.entity.UserOnboarding;
import useronboarding.service.UserOnBoardService;
import java.io.IOException;
import java.util.List;


@RestController
public class UserOnboardController {

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    private UserOnBoardService userOnBoardService;

    private static final Logger LOGGER = LoggerFactory.getLogger(UserOnboardController.class);


    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            value = "/users")
    public ResponseEntity createUser(@Valid @RequestBody UserOnBoardDto userOnBoardDto){
        UserOnboarding userOnboarding = modelMapper.map(userOnBoardDto,UserOnboarding.class);
        UserOnboarding userOnboardingResponse = userOnBoardService.createUser(userOnboarding);
        UserOnBoardDto userOnBoardDtoResponse = modelMapper.map(userOnboardingResponse,UserOnBoardDto.class);
        return new ResponseEntity(userOnBoardDtoResponse, HttpStatus.CREATED);
    }

    @GetMapping(produces=MediaType.APPLICATION_JSON_VALUE,
            value="/users")
    public ResponseEntity getUsers() {
        List<UserOnboarding> users = userOnBoardService.getAllUsers();
        return new ResponseEntity(users, HttpStatus.OK);
    }

    @PostMapping(value = "/users/{userId}/documents")
    public ResponseEntity<String> uploadFiles(@PathVariable("userId") String userId, @RequestParam MultipartFile[] files) throws IOException {
        userOnBoardService.uploadFiles(userId, files);
        return ResponseEntity.ok().body("File(s) uploaded Successfully");
    }

    @GetMapping(produces=MediaType.APPLICATION_JSON_VALUE,
            value="/users/{id}")
    public ResponseEntity getUserBasedOnId(@PathVariable ("id") String id ) {
        UserOnboarding user = userOnBoardService.getUserBasedOnId(id);
        UserOnBoardDto userOnBoardDto = modelMapper.map(user,UserOnBoardDto.class);
        return new ResponseEntity(userOnBoardDto, HttpStatus.OK);
    }



}
