package useronboarding.controller;

public @interface Valid {
}
