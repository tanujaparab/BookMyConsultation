package useronboarding;

public class ObjectMetadata {
}
