package useronboarding.repository;


import org.springframework.data.mongodb.repository.MongoRepository;
import useronboarding.entity.UserOnboarding;

public interface UserDao extends MongoRepository<UserOnboarding, String> {
}
