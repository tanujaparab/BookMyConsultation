package useronboarding.repository;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;

import jdk.javadoc.internal.doclets.formats.html.resources.standard;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import useronboarding.ObjectMetadata;

import javax.annotation.PostConstruct;
import java.io.IOException;

@Component
public class S3Repository {

    private String BUCKET_NAME="bmc.userservice.kartheek.s3.documents";
    private AmazonS3 s3Client;

    @Autowired
    ObjectMetadata metadata;


    @PostConstruct
    public AmazonS3 createS3Client() {
        String accessKey ="AKIAVV233P2DN25Y4XXU";
        String secretKey ="BJlu/DP9i7vifXnirhDJMN6xeQEh7kPZTPoI3sb5masw";
        AWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
        standard AmazonS3ClientBuilder = null;
        assert AmazonS3ClientBuilder != null;
        s3Client=AmazonS3ClientBuilder
                .standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withRegion(Regions.US_EAST_1)
                .build();

        return s3Client;
    }

    public void uploadFiles(String doctorId, MultipartFile file) throws IOException {
        String key = doctorId + "/" + file.getOriginalFilename();
        if(!s3Client.doesBucketExistV2(BUCKET_NAME)){
            s3Client.createBucket(BUCKET_NAME);
        }
        s3Client.putObject(BUCKET_NAME, key, file.getInputStream(), metadata);
    }



}


