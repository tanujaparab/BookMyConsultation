package useronboarding.repository;

public class BasicAWSCredentials {
    public BasicAWSCredentials(String accessKey, String secretKey) {
    }
}
