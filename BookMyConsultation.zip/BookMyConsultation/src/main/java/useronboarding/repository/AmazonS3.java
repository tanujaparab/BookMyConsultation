package useronboarding.repository;

import useronboarding.ObjectMetadata;

import java.io.InputStream;

public class AmazonS3 {
    public void createBucket(String bucket_name) {
    }

    public boolean doesBucketExistV2(String bucket_name) {
    }

    public void putObject(String bucket_name, String key, InputStream inputStream, ObjectMetadata metadata) {
    }
}
