package useronboarding.exception.handler;

import bookmyconsultation.Doctor.exception.RecordNotFoundException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

@ControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {
    private static final String ERR_INVALID_INPUT = "ERR_INVALID_INPUT";
    private static final String NO_RECORDS_FOUND ="ERR_RESOURCE_NOT_FOUND";

    @ExceptionHandler(RecordNotFoundException.class)
    public final ResponseEntity<Object> handleRecordNotFoundException(RecordNotFoundException e){
        Map<String, Object> body=new LinkedHashMap<>();
        body.put("errorCode", NO_RECORDS_FOUND);
        body.put("errorMessage",e.getLocalizedMessage());
        body.put("errorfields", null);
        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }


  /*  @ExceptionHandler({AccessDeniedException.class})
    public final ResponseEntity<String> handleAccessDeniedException(AccessDeniedException exception, WebRequest request) {
        return new ResponseEntity<>("Access is denied", HttpStatus.FORBIDDEN);
    }*/

    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders httpHeaders, HttpStatus httpStatus, WebRequest webRequest){

        Map<String, Object> body=new LinkedHashMap<>();
        body.put("errorCode", ERR_INVALID_INPUT);

        HashSet<String> errors= (HashSet<String>) ex.getBindingResult().getFieldErrors().stream().
                map(x -> x.getDefaultMessage()).collect(Collectors.toSet());

        body.put("errorMessage", errors);

        Map<String,String> errorMap = new HashMap<>();
        errorMap.put("firstName","First Name");
        errorMap.put("lastName","Last Name");
        errorMap.put("dob","Date of Birth");
        errorMap.put("emailId","Email ID");
        errorMap.put("mobile","Mobile");

        HashSet<String> errorFields= (HashSet<String>) ex.getBindingResult().getFieldErrors().stream()
                .map(x -> errorMap.get(x.getField())).collect(Collectors.toSet());

        body.put("errorfields", errorFields);
        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }
}
