package useronboarding.service;


import org.springframework.web.multipart.MultipartFile;
import useronboarding.entity.UserOnboarding;

import java.io.IOException;
import java.util.List;

public interface UserOnBoardService {

    UserOnboarding createUser(UserOnboarding userOnboarding);

    UserOnboarding getUserBasedOnId(String id);


    UserOnboarding updateUser(UserOnboarding userOnboarding);

    List<UserOnboarding> getAllUsers();

    void uploadFiles(String userId, MultipartFile[] files) throws IOException;
}
