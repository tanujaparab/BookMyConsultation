package useronboarding.service;


import bookmyconsultation.Doctor.exception.RecordNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import useronboarding.entity.UserOnboarding;
import useronboarding.repository.S3Repository;
import useronboarding.repository.UserDao;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
public class UserOnboardServiceImpl implements UserOnBoardService{

    @Autowired
    UserDao userDao;

    @Autowired
    S3Repository s3Repository;

    @Autowired
    ProducerService producerService;

    @Override
    public UserOnboarding createUser(UserOnboarding userOnboarding) {
        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String strDate = dateFormat.format(date);
        userOnboarding.setCreationDate(strDate);
        userOnboarding.setId(userIdGenerator());
        UserOnboarding savedUser = userDao.save(userOnboarding);
        producerService.publishUser(savedUser);
        return savedUser;
    }

    private UserOnboarding checkUserDetailsBasedOnId(String ratingId) {
        try {
            UserOnboarding userOnboarding = userDao.findById(ratingId).get();
            if (userOnboarding != null)
                return userOnboarding;
        }catch (Exception e){}
        return null;
    }

    private String userIdGenerator() {
        UUID userId = UUID.randomUUID();
        String userIdStr = userId.toString();
        UserOnboarding userOnboarding = checkUserDetailsBasedOnId(userIdStr);
        if(userOnboarding!=null)
            userIdGenerator();
        return userIdStr;
    }

    @Override
    public UserOnboarding getUserBasedOnId(String id) {
        try{
            UserOnboarding savedUser =  userDao.findById(id).get();
            if(savedUser!=null)
                return savedUser;

        }catch(Exception ex){
            throw new RecordNotFoundException("Requested resource is not available");
        }
        return null;
    }

    @Override
    public UserOnboarding updateUser(UserOnboarding userOnboarding) {
        return null;
    }

    @Override
    public List<UserOnboarding> getAllUsers() {
        return null;
    }

    @Override
    public void uploadFiles(String userId, MultipartFile[] files) throws IOException {
      UserOnboarding userOnboarding =  getUserBasedOnId(userId);
      if(userOnboarding!=null) {
          for (MultipartFile file : files) {
              s3Repository.uploadFiles(userId, file);
          }
      }
    }
}
