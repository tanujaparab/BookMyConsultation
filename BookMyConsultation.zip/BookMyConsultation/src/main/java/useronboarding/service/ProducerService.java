package useronboarding.service;


import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import useronboarding.entity.UserOnboarding;

@Log4j2
@RequiredArgsConstructor
@Service
public class ProducerService {

    @Value("${producer.topic}")
    private String producerTopic;

    private final KafkaTemplate<String, UserOnboarding> kafkaTemplate;

    public void publishUser(UserOnboarding userOnboarding){
        log.info("Publishing "+userOnboarding);
        kafkaTemplate.send(producerTopic,userOnboarding);
    }
}
