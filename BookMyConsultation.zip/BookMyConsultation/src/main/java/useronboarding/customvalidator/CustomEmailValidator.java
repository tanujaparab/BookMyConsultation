package useronboarding.customvalidator;

import jakarta.validation.Constraint;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import org.springframework.messaging.handler.annotation.Payload;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Email(message = "Invalid input. Parameter name: ")
@Pattern(regexp = ".+@.+\\..+", message = "Invalid input. Parameter name: ")
@Target({ElementType.METHOD, ElementType.FIELD, ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {})
public @interface CustomEmailValidator {
    String message() default "Invalid input. Parameter name: ";
    Class<?>[] groups() default {};
    Class<? extends Payload> [] payload() default {};
}
