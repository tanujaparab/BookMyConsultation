class Scratch {
    public static void main(String[] args) {
        }
    }
}